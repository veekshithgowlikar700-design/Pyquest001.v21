package com.snakebyte.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Display;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import org.json.JSONArray;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int ttsPending = 0;
    private final java.util.HashMap<String, String> trCache = new java.util.HashMap<String, String>();

    private void js(final String code) {
        runOnUiThread(new Runnable() { @Override public void run() { if (webView != null) webView.evaluateJavascript(code, null); } });
    }

    private void initTts() {
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                ttsReady = (status == TextToSpeech.SUCCESS);
                if (ttsReady) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) {}
                        @Override public void onError(String id) { finishOne(); }
                        @Override public void onDone(String id) { finishOne(); }
                    });
                }
            }
        });
    }

    private synchronized void finishOne() {
        ttsPending--;
        if (ttsPending <= 0) { ttsPending = 0; js("window.__tts&&__tts.ended()"); }
    }

    /** Read-aloud (English / Telugu) for the web UI. */
    private class SpeechBridge {
        /** 0 = voice ready, 1 = language voice data missing, 2 = engine not ready */
        @JavascriptInterface
        public int check(String lang) {
            if (!ttsReady || tts == null) return 2;
            Locale loc = "te".equals(lang) ? new Locale("te", "IN") : new Locale("en", "IN");
            int r = tts.isLanguageAvailable(loc);
            if (r < TextToSpeech.LANG_AVAILABLE && "en".equals(lang)) r = tts.isLanguageAvailable(Locale.US);
            return r >= TextToSpeech.LANG_AVAILABLE ? 0 : 1;
        }
        @JavascriptInterface
        public void speak(final String json, final String lang, final float rate) {
            runOnUiThread(new Runnable() { @Override public void run() {
                if (!ttsReady) { js("window.__tts&&__tts.ended()"); return; }
                try {
                    Locale loc = "te".equals(lang) ? new Locale("te", "IN") : new Locale("en", "IN");
                    if (tts.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE && "en".equals(lang)) loc = Locale.US;
                    tts.setLanguage(loc);
                    tts.setSpeechRate(rate);
                    tts.setPitch(1.0f);
                    tts.stop();
                    JSONArray a = new JSONArray(json);
                    synchronized (MainActivity.this) { ttsPending = a.length(); }
                    for (int i = 0; i < a.length(); i++) {
                        tts.speak(a.getString(i), TextToSpeech.QUEUE_ADD, null, "sb" + i);
                    }
                    if (a.length() == 0) js("window.__tts&&__tts.ended()");
                } catch (Throwable t) { js("window.__tts&&__tts.ended()"); }
            }});
        }
        @JavascriptInterface
        public void stop() {
            runOnUiThread(new Runnable() { @Override public void run() {
                synchronized (MainActivity.this) { ttsPending = 0; }
                if (tts != null) tts.stop();
            }});
        }
        @JavascriptInterface
        public void installVoice() {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    Intent i = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Throwable t) {
                    try { startActivity(new Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable ignored) {}
                }
            }});
        }
        /** Translate English text to Telugu (needs internet once; results are cached). */
        @JavascriptInterface
        public void translate(final String id, final String text) {
            new Thread(new Runnable() { @Override public void run() {
                String out = null;
                synchronized (trCache) { out = trCache.get(text); }
                if (out == null) {
                    try {
                        URL u = new URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=te&dt=t&q=" + URLEncoder.encode(text, "UTF-8"));
                        HttpURLConnection c = (HttpURLConnection) u.openConnection();
                        c.setConnectTimeout(8000); c.setReadTimeout(10000);
                        c.setRequestProperty("User-Agent", "Mozilla/5.0");
                        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder(); String ln;
                        while ((ln = br.readLine()) != null) sb.append(ln);
                        br.close();
                        JSONArray root = new JSONArray(sb.toString());
                        JSONArray segs = root.getJSONArray(0);
                        StringBuilder r = new StringBuilder();
                        for (int i = 0; i < segs.length(); i++) r.append(segs.getJSONArray(i).getString(0));
                        out = r.toString();
                        synchronized (trCache) { trCache.put(text, out); }
                    } catch (Throwable t) { out = null; }
                }
                final String res = out == null ? "" : out;
                js("window.__tts&&__tts.tr(" + org.json.JSONObject.quote(id) + "," + org.json.JSONObject.quote(res) + ")");
            }}).start();
        }
    }

    /** Lets the web UI match the status/navigation bar colour to light or dark mode. */
    private class Bridge {
        @JavascriptInterface
        public void setTheme(final boolean dark) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int bg = dark ? Color.parseColor("#000000") : Color.parseColor("#F2F2F7");
                    getWindow().setStatusBarColor(bg);
                    getWindow().setNavigationBarColor(bg);
                    View decor = getWindow().getDecorView();
                    int f = decor.getSystemUiVisibility();
                    if (dark) {
                        f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    } else {
                        f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        if (dark) {
                            f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        } else {
                            f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        }
                    }
                    decor.setSystemUiVisibility(f);
                }
            });
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }

        requestHighRefreshRate(window);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        // GPU-rasterised, composited WebView layer for smooth scrolling.
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setTextZoom(100);
        settings.setLoadWithOverviewMode(false);
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.addJavascriptInterface(new SpeechBridge(), "AndroidSpeech");
        initTts();
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Ask for the display's fastest mode (90/120 Hz where available) so motion is as smooth as the panel allows. */
    private void requestHighRefreshRate(Window window) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            Display display = getWindowManager().getDefaultDisplay();
            Display.Mode cur = display.getMode();
            Display.Mode best = cur;
            for (Display.Mode m : display.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth()
                        && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > best.getRefreshRate()) {
                    best = m;
                }
            }
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            window.setAttributes(lp);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript("(window.__back && window.__back())", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) {
                    finish();
                }
            }
        });
    }
}
